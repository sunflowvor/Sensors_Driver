=========
version.h
=========

.. contents::
    :local:

Version
=======

.. doxygenstruct:: ouster::util::version
    :members:

.. doxygenfunction:: ouster::util::to_string

.. doxygenfunction:: ouster::util::version_of_string

.. doxygengroup:: ouster_client_version_operators
    :content-only:
      
